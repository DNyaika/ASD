package strategy.headfast;

public interface QuackBehavior {
	public void quack();
}
