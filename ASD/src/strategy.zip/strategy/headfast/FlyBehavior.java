package strategy.headfast;

public interface FlyBehavior {
	public void fly();
}
