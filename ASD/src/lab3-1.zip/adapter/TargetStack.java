package adapter;

public interface TargetStack {
	public void push(String str);

	public String pop();

	public boolean isEmpty();
}
