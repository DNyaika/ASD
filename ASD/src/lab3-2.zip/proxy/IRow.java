package proxy;

public interface IRow {
	// the interface a concrete Row class implements ...
}
