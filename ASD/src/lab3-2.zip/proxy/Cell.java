package proxy;

public class Cell {

	private String value;

	public Cell(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
